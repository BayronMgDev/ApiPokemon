package com.proyectofinal.pokemonapi.Common;

import android.content.Intent;

import com.proyectofinal.pokemonapi.Model.Pokemon;
import java.util.ArrayList;
import java.util.List;

public class Common {
    public static final String KEY_ENEABLE_HOME = "enable_home";
    public static List<Pokemon> commonPokemonList = new ArrayList<>();
}
